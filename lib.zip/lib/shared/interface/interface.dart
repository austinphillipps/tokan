// lib/shared/interface/interface.dart

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/providers/plugin_provider.dart';
import '../../core/services/plugin_registry.dart';

import '../../features/dashboard/views/dashboard_screen.dart';
import '../../features/tasks/views/tasks_screen.dart';
import '../../features/calendar/views/calendar_screen.dart';
import '../../features/projects/views/projects_screen.dart';      // <-- ProjectsScreen sans const
import '../../settings/views/settings_screen.dart';
import '../../features/chat/views/messages_screen.dart';
import '../../features/collaborators/views/collaborators_screen.dart';
import '../../features/notifications/views/notifications_screen.dart';
import '../../features/library/views/library_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  bool _sidebarExpanded = false;
  bool _showLabels = false;
  Timer? _labelTimer;

  final ValueNotifier<int> _calendarRefreshNotifier = ValueNotifier<int>(0);

  @override
  void dispose() {
    _labelTimer?.cancel();
    super.dispose();
  }

  void _onMouseEnter(_) {
    _labelTimer?.cancel();
    setState(() => _sidebarExpanded = true);
    _labelTimer = Timer(const Duration(milliseconds: 200), () {
      if (_sidebarExpanded) setState(() => _showLabels = true);
    });
  }

  void _onMouseExit(_) {
    _labelTimer?.cancel();
    setState(() {
      _showLabels = false;
      _sidebarExpanded = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    // Couleurs extraites du thème
    final sidebarBg = theme.colorScheme.surface;
    final mainBg = theme.colorScheme.background;
    final dividerColor = theme.colorScheme.onBackground.withOpacity(0.3);

    // Couleurs pour les icônes
    final iconColorDefault = theme.colorScheme.onSurface;
    final iconColorSelected = theme.colorScheme.primary;

    // Couleur de fond pour l’item sélectionné
    final selectedItemBg = isDark
        ? theme.colorScheme.surfaceVariant ?? Colors.grey[800]!
        : theme.colorScheme.surfaceVariant ?? Colors.grey[200]!;

    // Récupérer le PluginProvider pour savoir quels plugins sont installés
    final pluginProv = context.watch<PluginProvider>();

    // 1) Liste « par défaut » des écrans (Dashboard → Paramètres)
    final List<Widget> defaultPages = [
      const DashboardScreen(),                       //  0
      const TasksPage(),                             //  1
      CalendarPage(refreshNotifier: _calendarRefreshNotifier), //  2
      const CollaboratorsPage(),                     //  3
      const MessagesPage(),                          //  4
      const NotificationsPage(),                     //  5
      const LibraryPage(),                           //  6
      ProjectsScreen(),                              //  7 ← Retiré le const
      const SettingsPage(),                          //  8
    ];

    // 2) Icônes par défaut correspondant aux indices 0..8
    final List<IconData> defaultIcons = [
      Icons.home,           //  0 (Dashboard)
      Icons.task_alt,       //  1 (Tâches)
      Icons.calendar_today, //  2 (Calendrier)
      Icons.group,          //  3 (Collaborateurs)
      Icons.message,        //  4 (Messages)
      Icons.notifications,  //  5 (Notifications)
      Icons.library_books,  //  6 (Library)
      Icons.work,           //  7 (Projets)
      Icons.settings,       //  8 (Paramètres)
    ];

    // 3) Labels par défaut correspondant aux indices 0..8
    final List<String> defaultLabels = [
      'Accueil',         // 0
      'Tâches',          // 1
      'Calendrier',      // 2
      'Collaborateurs',  // 3
      'Messages',        // 4
      'Notifications',   // 5
      'Library',         // 6
      'Projets',         // 7
      'Paramètres',      // 8
    ];

    // 4) Construire la liste FINALE des pages en injectant les plugins
    //    installés juste après l’index 7 (« Projets »).
    final List<Widget> pages = [
      // On garde tous les écrans de 0 à 7 (inclus)
      ...defaultPages.sublist(0, 8),
      // Pour chaque plugin installé, on ajoute son écran principal
      for (final plug in allPlugins)
        if (pluginProv.isInstalled(plug.id)) plug.buildMainScreen(context),
      // Puis on ajoute l’écran « Paramètres » (dernier)
      defaultPages.last,
    ];

    // 5) Construire la liste FINALE des icônes
    final List<IconData> icons = [
      ...defaultIcons.sublist(0, 8),
      for (final plug in allPlugins)
        if (pluginProv.isInstalled(plug.id))
        // Si plug.icon est un Icon, on en extrait l’IconData, sinon fallback
          (plug.icon is Icon ? (plug.icon as Icon).icon! : Icons.extension),
      defaultIcons.last,
    ];

    // 6) Construire la liste FINALE des labels
    final List<String> labels = [
      ...defaultLabels.sublist(0, 8),
      for (final plug in allPlugins)
        if (pluginProv.isInstalled(plug.id)) plug.displayName,
      defaultLabels.last,
    ];

    return Scaffold(
      body: Row(
        children: [
          // ───────── Sidebar ─────────
          MouseRegion(
            onEnter: _onMouseEnter,
            onExit: _onMouseExit,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: _sidebarExpanded ? 180 : 60,
              color: sidebarBg,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 24),
                  // On affiche chaque item (sauf Notifications, Library, Paramètres)
                  // dans la partie « principale » de la sidebar
                  for (int i = 0; i < pages.length; i++)
                  // Notifications, Library et Paramètres sont en bas ⇒ on
                  // les gère séparément après le Spacer()
                    if (i != labels.indexOf('Notifications') &&
                        i != labels.indexOf('Library') &&
                        i != labels.indexOf('Paramètres'))
                      _buildNavItem(
                        index: i,
                        icon: icons[i],
                        label: labels[i],
                        iconColorDefault: iconColorDefault,
                        iconColorSelected: iconColorSelected,
                        selectedItemBg: selectedItemBg,
                      ),

                  const Spacer(),

                  // Notifications (en bas)
                  _buildNavIcon(
                    index: labels.indexOf('Notifications'),
                    icon: Icons.notifications,
                    iconColorDefault: iconColorDefault,
                    iconColorSelected: iconColorSelected,
                    selectedItemBg: selectedItemBg,
                  ),
                  const SizedBox(height: 8),

                  // Library
                  _buildNavIcon(
                    index: labels.indexOf('Library'),
                    icon: Icons.library_books,
                    iconColorDefault: iconColorDefault,
                    iconColorSelected: iconColorSelected,
                    selectedItemBg: selectedItemBg,
                  ),
                  const SizedBox(height: 8),

                  // Paramètres
                  _buildNavIcon(
                    index: labels.indexOf('Paramètres'),
                    icon: Icons.settings,
                    iconColorDefault: iconColorDefault,
                    iconColorSelected: iconColorSelected,
                    selectedItemBg: selectedItemBg,
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),

          // ───────── Séparateur ─────────
          VerticalDivider(width: 1, color: dividerColor),

          // ───────── Contenu principal ─────────
          Expanded(
            child: Container(
              color: mainBg,
              child: pages[_selectedIndex],
            ),
          ),
        ],
      ),
    );
  }

  /// Construit un item de navigation avec icône + texte (si sidebar étendue)
  Widget _buildNavItem({
    required int index,
    required IconData icon,
    required String label,
    required Color iconColorDefault,
    required Color iconColorSelected,
    required Color selectedItemBg,
  }) {
    final bool selected = index == _selectedIndex;
    return Material(
      color: selected ? selectedItemBg : Colors.transparent,
      child: InkWell(
        onTap: () => setState(() => _selectedIndex = index),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
          child: Row(
            children: [
              Icon(
                icon,
                color: selected ? iconColorSelected : iconColorDefault,
              ),
              if (_showLabels) ...[
                const SizedBox(width: 12),
                Text(
                  label,
                  style: TextStyle(
                    color: selected ? iconColorSelected : iconColorDefault,
                  ),
                ),
              ] else
                Tooltip(message: label, child: const SizedBox.shrink()),
            ],
          ),
        ),
      ),
    );
  }

  /// Construit uniquement l’icône (pour Notifications, Library, Paramètres)
  Widget _buildNavIcon({
    required int index,
    required IconData icon,
    required Color iconColorDefault,
    required Color iconColorSelected,
    required Color selectedItemBg,
  }) {
    final bool selected = index == _selectedIndex;
    return Material(
      color: selected ? selectedItemBg : Colors.transparent,
      child: InkWell(
        onTap: () => setState(() => _selectedIndex = index),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
          child: Tooltip(
            message: _labelsOrDynamicLabel(index),
            child: Icon(
              icon,
              color: selected ? iconColorSelected : iconColorDefault,
              size: 28,
            ),
          ),
        ),
      ),
    );
  }

  /// Retourne le label approprié (par défaut ou plugin)
  String _labelsOrDynamicLabel(int index) {
    // Pour extraire le label, on reconstruit la liste 'labels' de la même façon
    final pluginProv = context.read<PluginProvider>();
    final List<String> defaultLabels = [
      'Accueil',
      'Tâches',
      'Calendrier',
      'Collaborateurs',
      'Messages',
      'Notifications',
      'Library',
      'Projets',
      'Paramètres',
    ];

    final List<String> labels = [
      ...defaultLabels.sublist(0, 8),
      for (final plug in allPlugins)
        if (pluginProv.isInstalled(plug.id)) plug.displayName,
      defaultLabels.last,
    ];
    return labels[index];
  }
}
