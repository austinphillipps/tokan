import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../models/product.dart';
import '../models/stock_movement.dart';
import '../models/inventory_count.dart';
import '../providers/stock_provider.dart';
import '../utils/csv_utils.dart';

import 'stock_movement_dialog.dart';
import 'movement_history_screen.dart';
import 'inventory_count_screen.dart';
import 'inventory_history_screen.dart';

class StockScreen extends StatefulWidget {
  const StockScreen({Key? key}) : super(key: key);

  @override
  State<StockScreen> createState() => _StockScreenState();
}

class _StockScreenState extends State<StockScreen> {
  DateTime? _expiryDate;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<StockProvider>().fetchAllProducts();
    });
  }

  Future<void> _exportCsv(List<Product> products) async {
    final csv = CsvUtils.generateProductCsv(products);
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/export_produits.csv');
    await file.writeAsString(csv);
    await Share.shareXFiles([XFile(file.path)], text: 'Export Stock CSV');
  }

  Future<void> _importCsv() async {
    final importedProducts = await CsvUtils.pickAndParseProductCsv();
    if (importedProducts.isEmpty) return;

    final provider = context.read<StockProvider>();
    for (final p in importedProducts) {
      await provider.addProduct(p);
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${importedProducts.length} produits importés')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Gestion de stock'),
        actions: [
          IconButton(
            icon: const Icon(Icons.inventory_2),
            tooltip: 'Inventaire',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const InventoryCountScreen(),
                ),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.list_alt),
            tooltip: 'Historique inventaires',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const InventoryHistoryScreen(),
                ),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.upload_file),
            tooltip: 'Importer CSV',
            onPressed: _importCsv,
          ),
          IconButton(
            icon: const Icon(Icons.download_rounded),
            tooltip: 'Exporter CSV',
            onPressed: () {
              final products = context.read<StockProvider>().products;
              _exportCsv(products);
            },
          ),
        ],
      ),
      body: Consumer<StockProvider>(
        builder: (context, stockProv, _) {
          if (stockProv.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          final products = stockProv.products;
          if (products.isEmpty) {
            return const Center(child: Text("Aucun produit trouvé"));
          }

          return ListView.builder(
            itemCount: products.length,
            itemBuilder: (context, index) {
              final Product prod = products[index];
              Color? bgColor;
              if (prod.quantityInStock == 0) {
                bgColor = Colors.red.shade100;
              } else if (prod.quantityInStock <= prod.reorderThreshold) {
                bgColor = Colors.orange.shade100;
              }

              return Container(
                color: bgColor,
                child: ListTile(
                  title: Text(prod.name),
                  subtitle: Text("Quantité : ${prod.quantityInStock}"),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.swap_vert),
                        tooltip: 'Mouvement',
                        onPressed: () {
                          showDialog(
                            context: context,
                            builder: (_) => StockMovementDialog(product: prod),
                          );
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.history),
                        tooltip: 'Historique',
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => MovementHistoryScreen(product: prod),
                            ),
                          );
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.edit),
                        tooltip: 'Modifier',
                        onPressed: () {
                          _showAddProductDialog(context, existingProduct: prod);
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete),
                        tooltip: 'Supprimer',
                        onPressed: () {
                          context.read<StockProvider>().deleteProduct(prod.id);
                        },
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _showAddProductDialog(context);
        },
        child: const Icon(Icons.add),
        tooltip: 'Ajouter un produit',
      ),
    );
  }

  void _showAddProductDialog(BuildContext context, {Product? existingProduct}) {
    final _skuCtrl = TextEditingController(text: existingProduct?.sku ?? '');
    final _barcodeCtrl = TextEditingController(text: existingProduct?.barcode ?? '');
    final _nameCtrl = TextEditingController(text: existingProduct?.name ?? '');
    final _descCtrl = TextEditingController(text: existingProduct?.description ?? '');
    final _categoryCtrl = TextEditingController(text: existingProduct?.categoryId ?? '');
    final _supplierCtrl = TextEditingController(text: existingProduct?.supplierId ?? '');
    final _unitPriceCtrl = TextEditingController(text: (existingProduct?.unitPrice ?? 0.0).toString());
    final _costPriceCtrl = TextEditingController(text: (existingProduct?.costPrice ?? 0.0).toString());
    final _unitOfMeasureCtrl = TextEditingController(text: existingProduct?.unitOfMeasure ?? '');
    final _imageUrlCtrl = TextEditingController(text: existingProduct?.imageUrl ?? '');
    final _quantityCtrl = TextEditingController(text: (existingProduct?.quantityInStock ?? 0).toString());
    final _reorderThresholdCtrl = TextEditingController(text: (existingProduct?.reorderThreshold ?? 0).toString());
    final _reorderQuantityCtrl = TextEditingController(text: (existingProduct?.reorderQuantity ?? 0).toString());
    final _minimumStockCtrl = TextEditingController(text: (existingProduct?.minimumStock ?? 0).toString());
    final _maximumStockCtrl = TextEditingController(text: (existingProduct?.maximumStock ?? 0).toString());
    _expiryDate = existingProduct?.expiryDate;

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: Text(existingProduct == null ? 'Ajouter un produit' : 'Modifier le produit'),
              content: SingleChildScrollView(
                child: Column(
                  children: [
                    TextField(controller: _skuCtrl, decoration: const InputDecoration(labelText: 'SKU')),
                    TextField(controller: _barcodeCtrl, decoration: const InputDecoration(labelText: 'Code-barres')),
                    TextField(controller: _nameCtrl, decoration: const InputDecoration(labelText: 'Nom du produit')),
                    TextField(controller: _descCtrl, decoration: const InputDecoration(labelText: 'Description')),
                    TextField(controller: _categoryCtrl, decoration: const InputDecoration(labelText: 'ID Catégorie')),
                    TextField(controller: _supplierCtrl, decoration: const InputDecoration(labelText: 'ID Fournisseur')),
                    TextField(controller: _unitPriceCtrl, decoration: const InputDecoration(labelText: 'Prix unitaire'), keyboardType: TextInputType.numberWithOptions(decimal: true)),
                    TextField(controller: _costPriceCtrl, decoration: const InputDecoration(labelText: 'Coût d\'achat'), keyboardType: TextInputType.numberWithOptions(decimal: true)),
                    TextField(controller: _unitOfMeasureCtrl, decoration: const InputDecoration(labelText: 'Unité de mesure')),
                    TextField(controller: _imageUrlCtrl, decoration: const InputDecoration(labelText: 'URL de l\'image')),
                    TextField(controller: _quantityCtrl, decoration: const InputDecoration(labelText: 'Quantité en stock'), keyboardType: TextInputType.number),
                    TextField(controller: _reorderThresholdCtrl, decoration: const InputDecoration(labelText: 'Seuil de réapprovisionnement'), keyboardType: TextInputType.number),
                    TextField(controller: _reorderQuantityCtrl, decoration: const InputDecoration(labelText: 'Quantité suggérée à commander'), keyboardType: TextInputType.number),
                    TextField(controller: _minimumStockCtrl, decoration: const InputDecoration(labelText: 'Stock minimum'), keyboardType: TextInputType.number),
                    TextField(controller: _maximumStockCtrl, decoration: const InputDecoration(labelText: 'Stock maximum'), keyboardType: TextInputType.number),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Text('Date péremption: '),
                        TextButton(
                          onPressed: () async {
                            final picked = await showDatePicker(
                              context: context,
                              initialDate: _expiryDate ?? DateTime.now(),
                              firstDate: DateTime(2000),
                              lastDate: DateTime(2100),
                            );
                            if (picked != null) {
                              setState(() => _expiryDate = picked);
                            }
                          },
                          child: Text(
                            _expiryDate == null
                                ? 'Choisir'
                                : '${_expiryDate!.day}/${_expiryDate!.month}/${_expiryDate!.year}',
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Annuler'),
                ),
                ElevatedButton(
                  onPressed: () {
                    final now = DateTime.now();
                    final id = existingProduct?.id ?? const Uuid().v4();

                    final product = Product(
                      id: id,
                      sku: _skuCtrl.text.trim(),
                      barcode: _barcodeCtrl.text.trim(),
                      name: _nameCtrl.text.trim(),
                      description: _descCtrl.text.trim(),
                      categoryId: _categoryCtrl.text.trim(),
                      supplierId: _supplierCtrl.text.trim(),
                      unitPrice: double.tryParse(_unitPriceCtrl.text) ?? 0.0,
                      costPrice: double.tryParse(_costPriceCtrl.text) ?? 0.0,
                      unitOfMeasure: _unitOfMeasureCtrl.text.trim(),
                      imageUrl: _imageUrlCtrl.text.trim(),
                      quantityInStock: int.tryParse(_quantityCtrl.text) ?? 0,
                      reorderThreshold: int.tryParse(_reorderThresholdCtrl.text) ?? 0,
                      reorderQuantity: int.tryParse(_reorderQuantityCtrl.text) ?? 0,
                      minimumStock: int.tryParse(_minimumStockCtrl.text) ?? 0,
                      maximumStock: int.tryParse(_maximumStockCtrl.text) ?? 0,
                      dateCreated: existingProduct?.dateCreated ?? now,
                      dateUpdated: now,
                      expiryDate: _expiryDate,
                    );

                    if (existingProduct == null) {
                      context.read<StockProvider>().addProduct(product);
                    } else {
                      context.read<StockProvider>().updateProduct(product);
                    }

                    Navigator.of(context).pop();
                  },
                  child: Text(existingProduct == null ? 'Ajouter' : 'Enregistrer'),
                ),
              ],
            );
          },
        );
      },
    );
  }
}
